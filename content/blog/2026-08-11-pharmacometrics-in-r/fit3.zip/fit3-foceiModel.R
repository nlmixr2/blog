foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],WT);\ncmt(central);\nrx_expr_0~WT<1.3;\nrx_expr_1~WT>=1.3;\nrx_expr_2~ETA[1]+THETA[1];\nrx_expr_3~ETA[2]+THETA[2];\nrx_expr_4~(-1.3+WT)*THETA[6];\nrx_expr_5~(rx_expr_0)*(-1.3+WT);\nrx_expr_6~0.769230769230769*WT;\nrx_expr_7~log(rx_expr_6);\nrx_expr_8~rx_expr_5*THETA[5];\nrx_expr_9~rx_expr_4*(rx_expr_1);\nrx_expr_10~rx_expr_7*THETA[4];\nrx_expr_11~rx_expr_3+rx_expr_9;\nrx_expr_12~rx_expr_2+rx_expr_10;\nrx_expr_13~rx_expr_11+rx_expr_8;\nrx_expr_16~rx_expr_12-(rx_expr_13);\nrx_expr_17~exp(rx_expr_16);\nd/dt(central)=-rx_expr_17*central;\nd/dt(rx__sens_central_BY_ETA_1___)=-rx_expr_17*central-rx_expr_17*rx__sens_central_BY_ETA_1___;\nd/dt(rx__sens_central_BY_ETA_2___)=rx_expr_17*central-rx_expr_17*rx__sens_central_BY_ETA_2___;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_14~exp(-(rx_expr_13));\nrx_expr_15~rx_expr_14*central;\nrx_pred_=rx_expr_15;\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_14*rx__sens_central_BY_ETA_1___;\nrx__sens_rx_pred__BY_ETA_2___=-rx_expr_14*central+rx_expr_14*rx__sens_central_BY_ETA_2___;\nrx_r_=Rx_pow_di((rx_expr_15*THETA[3]),2);\ncmt(cp);\ndvid(2);\n")

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- "rx_expr_0~WT<1.3\nrx_expr_1~WT>=1.3\nrx_expr_2~ETA[1]+THETA[1]\nrx_expr_3~ETA[2]+THETA[2]\nrx_expr_4~(-1.3+WT)*THETA[6]\nrx_expr_5~(rx_expr_0)*(-1.3+WT)\nrx_expr_6~0.769230769230769*WT\nrx_expr_7~log(rx_expr_6)\nrx_expr_8~rx_expr_5*THETA[5]\nrx_expr_9~rx_expr_4*(rx_expr_1)\nrx_expr_10~rx_expr_7*THETA[4]\nrx_expr_11~rx_expr_3+rx_expr_9\nrx_expr_12~rx_expr_2+rx_expr_10\nrx_expr_13~rx_expr_11+rx_expr_8\nrx_expr_16~rx_expr_12-(rx_expr_13)\nrx_expr_17~exp(rx_expr_16)\nd/dt(central)=-rx_expr_17*central\nd/dt(rx__sens_central_BY_ETA_1___)=-rx_expr_17*central-rx_expr_17*rx__sens_central_BY_ETA_1___\nd/dt(rx__sens_central_BY_ETA_2___)=rx_expr_17*central-rx_expr_17*rx__sens_central_BY_ETA_2___\nrx_yj_~2\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_expr_14~exp(-(rx_expr_13))\nrx_expr_15~rx_expr_14*central\nrx_pred_=rx_expr_15\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_14*rx__sens_central_BY_ETA_1___\nrx__sens_rx_pred__BY_ETA_2___=-rx_expr_14*central+rx_expr_14*rx__sens_central_BY_ETA_2___\nrx_r_=Rx_pow_di((rx_expr_15*THETA[3]), 2)\nrx__ETA1=ETA[1]\nrx__ETA2=ETA[2]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],WT);\ncmt(central);\nrx_expr_0~WT<1.3;\nrx_expr_1~WT>=1.3;\nrx_expr_2~ETA[1]+THETA[1];\nrx_expr_3~ETA[2]+THETA[2];\nrx_expr_4~(-1.3+WT)*THETA[6];\nrx_expr_5~(rx_expr_0)*(-1.3+WT);\nrx_expr_6~0.769230769230769*WT;\nrx_expr_7~log(rx_expr_6);\nrx_expr_8~rx_expr_5*THETA[5];\nrx_expr_9~rx_expr_4*(rx_expr_1);\nrx_expr_10~rx_expr_7*THETA[4];\nrx_expr_11~rx_expr_3+rx_expr_9;\nrx_expr_12~rx_expr_2+rx_expr_10;\nrx_expr_13~rx_expr_11+rx_expr_8;\nd/dt(central)=-exp(rx_expr_12-(rx_expr_13))*central;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_14~exp(-(rx_expr_13));\nrx_expr_15~rx_expr_14*central;\nrx_pred_=rx_expr_15;\nrx_r_=Rx_pow_di((rx_expr_15*THETA[3]),2);\ntcl=THETA[1];\ntv=THETA[2];\nprop.sd=THETA[3];\nbeta.tcl.WT.power=THETA[4];\nbeta.tv.WT.hockey.low=THETA[5];\nbeta.tv.WT.hockey.hi=THETA[6];\neta.cl=ETA[1];\neta.v=ETA[2];\ncl=exp(rx_expr_12);\nv=exp(rx_expr_13);\ncp=rx_expr_15;\ntad=tad();\ndosenum=dosenum();\ncmt(cp);\ndvid(2);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],WT);\ncmt(central);\nparam(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],WT);\nrx_expr_0~WT<1.3;\nrx_expr_1~WT>=1.3;\nrx_expr_2~ETA[2]+THETA[2];\nrx_expr_3~(-1.3+WT)*THETA[6];\nrx_expr_4~(rx_expr_0)*(-1.3+WT);\nrx_expr_5~rx_expr_4*THETA[5];\nrx_expr_6~rx_expr_3*(rx_expr_1);\nrx_expr_7~rx_expr_2+rx_expr_6;\nrx_expr_8~rx_expr_7+rx_expr_5;\nd/dt(central)=-exp(ETA[1]+THETA[1]+log(0.769230769230769*WT)*THETA[4]-(rx_expr_8))*central;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_9~exp(-(rx_expr_8));\nrx_expr_10~rx_expr_9*central;\nrx_pred_=rx_expr_10;\nrx_r_=Rx_pow_di((rx_expr_10*THETA[3]),2);\ncmt(cp);\ndvid(2);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- c(0L, 0L)

class(foceiModel) <- "foceiModelList"

