`fit3` <- function() {
source('fit3-env.R', local=TRUE)
.class <- env$`..class..`
.id.level <- env$`..id.level..`
.parHistType.level <- env$`..parHistType.level..`
rm('..class..', envir=env)
rm('..id.level..', envir=env)
if (exists('..parHistType.level..', env)) rm('..parHistType.level..', envir=env)
env$`etaObf` <- read.csv('fit3-etaObf.csv', check.names=FALSE)

source('fit3-foceiModel.R', local=TRUE)
env$`foceiModel` <- foceiModel

source('fit3-iniDf0.R', local=TRUE)
env$`iniDf0` <- iniDf0

env$objDf <- read.csv('fit3-objDf.csv',check.names=FALSE, row.names=1)
env$objDf$OBJF <- as.double(env$objDf$OBJF)
env$objDf$AIC <- as.double(env$objDf$AIC)
env$objDf$BIC <- as.double(env$objDf$BIC)
env$objDf$`Log-likelihood` <- as.double(env$objDf$`Log-likelihood`)

env$`origData` <- read.csv('fit3-origData.csv', check.names=FALSE)

env$`parFixed` <- read.csv('fit3-parFixed.csv',check.names=FALSE, row.names=1, colClasses="character")
class(env$`parFixed`) <- c('nlmixr2ParFixed', 'data.frame')

env$`parFixedDf` <- read.csv('fit3-parFixedDf.csv',check.names=FALSE, row.names=1)
env$`parFixedDf` <- nlmixr2save::nlmixr2saveParFixedDf(env$`parFixedDf`, named=TRUE)

env$`parHistData` <- read.csv('fit3-parHistData.csv', check.names=FALSE)

source('fit3-phiC.R', local=TRUE)
env$`phiC` <- phiC

source('fit3-phiH.R', local=TRUE)
env$`phiH` <- phiH

env$`ranef` <- read.csv('fit3-ranef.csv', check.names=FALSE)

env$`scaleInfo` <- readRDS('fit3-scaleInfo.rds')

env$`sessioninfo` <- readRDS('fit3-sessioninfo.rds')

env$`shrink` <- read.csv('fit3-shrink.csv',check.names=FALSE, row.names=1)

env$`time` <- read.csv('fit3-time.csv',check.names=FALSE, row.names=1)

source('fit3-ui.R', local=TRUE)
env$`ui` <- ui
env$model <- rxode2::model(env$ui)
if (!is.null(.id.level)) {
  if (!is.null(env$ranef$ID)) {
    env$ranef$ID <- factor(env$ranef$ID, levels=.id.level)
  }
  if (!is.null(env$etaObf$ID)) {
    env$etaObf$ID <- factor(env$etaObf$ID, levels=.id.level)
  }
}
if (!is.null(env$parHistData)) {
  .phLevels <- .parHistType.level
  if (is.null(.phLevels)) {
    .phLevels <- c("Gill83 Gradient", "Mixed Gradient", "Forward Difference", "Central Difference", "Scaled", "Unscaled", "Back-Transformed", "Forward Sensitivity", "Analytic Gradient")
    .phLevels <- c(.phLevels, setdiff(unique(as.character(env$parHistData$type)), .phLevels))
  }
  env$parHistData$type <- factor(env$parHistData$type, levels=.phLevels)
  env$parHistData$iter <- as.integer(env$parHistData$iter)
}
if (exists('saemControl', env) && is.numeric(env$saemControl$mcmc$niter[1])) {
    .parHistData <- env$parHistData
    .cls <- class(.parHistData)
    attr(.cls, 'niter') <- env$saemControl$mcmc$niter[1]
    class(.parHistData) <- .cls
    env$parHistData <- .parHistData
}
if (any(.class == 'nlmixr2FitData')) {
  ret <- read.csv('fit3.csv')
  class(env) <- 'nlmixr2FitCoreSilent'
  attr(.class, '.foceiEnv') <- env
  class(ret) <- .class
  return(ret)
} else {
  ret <- env
  class(ret) <- .class
  return(ret)
}
}
`fit3` <- `fit3`()

