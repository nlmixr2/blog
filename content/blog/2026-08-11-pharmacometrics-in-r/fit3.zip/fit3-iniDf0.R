iniDf0 <- function () 
{
    ini({
        tcl <- -4.8283137373023
        tv <- -0.510825623765991
        prop.sd <- c(0, 0.1)
        eta.cl ~ 1
        eta.v ~ 1
    })
    model({
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(central) <- -(cl/v) * central
        cp <- central/v
        cp ~ prop(prop.sd)
    })
}
iniDf0 <- rxode2::rxode2(iniDf0)
iniDf0 <- rxode2::rxUiDecompress(iniDf0)
assign("modelName", "pheno", envir=, iniDf0)
rm("model", envir=iniDf0)
iniDf0 <- rxode2::rxUiCompress(iniDf0)

