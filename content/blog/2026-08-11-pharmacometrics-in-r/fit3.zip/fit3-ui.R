ui <- function () 
{
    ini({
        tcl <- -5.12324963707
        tv <- 0.272887052962
        prop.sd <- c(0, 0.140552353242)
        beta.tcl.WT.power <- 0.63360525514
        beta.tv.WT.hockey.low <- 0.948671628394
        beta.tv.WT.hockey.hi <- 0.520321310437
        eta.cl ~ 0.0255003432707
        eta.v ~ 0.0190594819482
    })
    model({
        cl <- exp(tcl + beta.tcl.WT.power * log(WT/1.3) + eta.cl)
        v <- exp(tv + beta.tv.WT.hockey.low * (WT < 1.3) * (WT - 
            1.3) + beta.tv.WT.hockey.hi * (WT >= 1.3) * (WT - 
            1.3) + eta.v)
        d/dt(central) <- -(cl/v) * central
        cp <- central/v
        cp ~ prop(prop.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "x", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

