ui <- function () 
{
    ini({
        tcl <- -5.11963281833587
        tv <- 0.266487879977522
        prop.sd <- c(0, 0.113772750390624)
        cov.cl.wt <- 1.10185511734818
        cov.v.wt <- 0.939576022444236
        eta.cl ~ 0.027727477793178
        eta.v ~ 0.031749400531128
    })
    model({
        cl <- exp(tcl + eta.cl + nlmixrMuDerCov1 * cov.cl.wt)
        v <- exp(tv + eta.v + nlmixrMuDerCov2 * cov.v.wt)
        d/dt(central) <- -(cl/v) * central
        cp <- central/v
        cp ~ prop(prop.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "rxui$fun", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

