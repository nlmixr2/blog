saemModel <- list()

saemModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],ETA[1],ETA[2]);\ncmt(central);\nrx_pred_=NA;\nrx_r_=NA;\ntcl=THETA[1]+ETA[1];\ntv=THETA[2]+ETA[2];\nprop.sd=THETA[3];\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nd/dt(central)=-exp(tcl-tv)*central;\nrx_pred_=exp(-tv)*central;\nrx_expr__0~exp(-tv);\nrx_expr__1~rx_expr__0*central;\nrx_r_=Rx_pow_di((rx_expr__1*prop.sd),2);\ncl=exp(tcl);\nv=exp(tv);\ncp=rx_expr__1;\ntad=tad();\ndosenum=dosenum();\ntcl=THETA[1];\ntv=THETA[2];\nprop.sd=THETA[3];\neta.cl=ETA[1];\neta.v=ETA[2];\ncmt(cp);\ndvid(2);\n")

class(saemModel) <- "saemModelList"

