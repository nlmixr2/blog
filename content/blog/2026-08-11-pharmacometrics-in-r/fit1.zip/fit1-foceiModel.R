foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],ETA[1],ETA[2]);\ncmt(central);\nrx_expr_0~ETA[1]+THETA[1];\nrx_expr_1~ETA[2]+THETA[2];\nrx_expr_5~rx_expr_0-(rx_expr_1);\nrx_expr_6~exp(rx_expr_5);\nd/dt(central)=-rx_expr_6*central;\nd/dt(rx__sens_central_BY_ETA_1___)=-rx_expr_6*central-rx_expr_6*rx__sens_central_BY_ETA_1___;\nd/dt(rx__sens_central_BY_ETA_2___)=rx_expr_6*central-rx_expr_6*rx__sens_central_BY_ETA_2___;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_2~exp(-(rx_expr_1));\nrx_expr_4~rx_expr_2*central;\nrx_pred_=rx_expr_4;\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_2*rx__sens_central_BY_ETA_1___;\nrx__sens_rx_pred__BY_ETA_2___=-rx_expr_2*central+rx_expr_2*rx__sens_central_BY_ETA_2___;\nrx_expr_7~rx_expr_4*THETA[3];\nrx_r_=Rx_pow_di((rx_expr_7),2);\nrx_expr_3~2*rx_expr_2;\nrx__sens_rx_r__BY_ETA_1___=rx_expr_3*rx__sens_central_BY_ETA_1___*(rx_expr_7)*THETA[3];\nrx__sens_rx_r__BY_ETA_2___=-2*rx_expr_2*central*(rx_expr_7)*THETA[3]+rx_expr_3*rx__sens_central_BY_ETA_2___*(rx_expr_7)*THETA[3];\ncmt(cp);\ndvid(2);\n")

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- "rx_expr_0~ETA[1]+THETA[1]\nrx_expr_1~ETA[2]+THETA[2]\nrx_expr_5~rx_expr_0-(rx_expr_1)\nrx_expr_6~exp(rx_expr_5)\nd/dt(central)=-rx_expr_6*central\nd/dt(rx__sens_central_BY_ETA_1___)=-rx_expr_6*central-rx_expr_6*rx__sens_central_BY_ETA_1___\nd/dt(rx__sens_central_BY_ETA_2___)=rx_expr_6*central-rx_expr_6*rx__sens_central_BY_ETA_2___\nrx_yj_~2\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_expr_2~exp(-(rx_expr_1))\nrx_expr_4~rx_expr_2*central\nrx_pred_=rx_expr_4\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_2*rx__sens_central_BY_ETA_1___\nrx__sens_rx_pred__BY_ETA_2___=-rx_expr_2*central+rx_expr_2*rx__sens_central_BY_ETA_2___\nrx_expr_7~rx_expr_4*THETA[3]\nrx_r_=Rx_pow_di((rx_expr_7), 2)\nrx_expr_3~2*rx_expr_2\nrx__sens_rx_r__BY_ETA_1___=rx_expr_3*rx__sens_central_BY_ETA_1___*(rx_expr_7)*THETA[3]\nrx__sens_rx_r__BY_ETA_2___=-2*rx_expr_2*central*(rx_expr_7)*THETA[3]+rx_expr_3*rx__sens_central_BY_ETA_2___*(rx_expr_7)*THETA[3]\nrx__ETA1=ETA[1]\nrx__ETA2=ETA[2]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],ETA[1],ETA[2]);\ncmt(central);\nrx_expr_0~ETA[1]+THETA[1];\nrx_expr_1~ETA[2]+THETA[2];\nd/dt(central)=-exp(rx_expr_0-(rx_expr_1))*central;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_2~exp(-(rx_expr_1));\nrx_expr_3~rx_expr_2*central;\nrx_pred_=rx_expr_3;\nrx_r_=Rx_pow_di((rx_expr_3*THETA[3]),2);\ntcl=THETA[1];\ntv=THETA[2];\nprop.sd=THETA[3];\neta.cl=ETA[1];\neta.v=ETA[2];\ncl=exp(rx_expr_0);\nv=exp(rx_expr_1);\ncp=rx_expr_3;\ntad=tad();\ndosenum=dosenum();\ncmt(cp);\ndvid(2);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],ETA[1],ETA[2]);\ncmt(central);\nparam(THETA[1],THETA[2],THETA[3],ETA[1],ETA[2]);\nrx_expr_0~ETA[2]+THETA[2];\nd/dt(central)=-exp(ETA[1]+THETA[1]-(rx_expr_0))*central;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_1~exp(-(rx_expr_0));\nrx_expr_2~rx_expr_1*central;\nrx_pred_=rx_expr_2;\nrx_r_=Rx_pow_di((rx_expr_2*THETA[3]),2);\ncmt(cp);\ndvid(2);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L)

foceiModel[["eventEta"]] <- c(0L, 0L)

class(foceiModel) <- "foceiModelList"

