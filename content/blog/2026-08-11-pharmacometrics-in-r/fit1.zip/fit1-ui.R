ui <- function () 
{
    ini({
        tcl <- -5.17637045082277
        tv <- 0.350604150290304
        prop.sd <- c(0, 0.124838665325872)
        eta.cl ~ 0.129218983083134
        eta.v ~ 0.19890470423496
    })
    model({
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(central) <- -(cl/v) * central
        cp <- central/v
        cp ~ prop(prop.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "pheno", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

