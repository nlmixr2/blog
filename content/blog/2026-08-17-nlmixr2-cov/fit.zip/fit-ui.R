ui <- function () 
{
    ini({
        tcl <- -0.474428030411699
        tv <- 3.50519290941885
        add.sd <- c(0, 0.950536306074458)
        eta.cl ~ 10.7416431716772
        eta.v ~ c(7.25074355928956, 4.99997025323507)
    })
    model({
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        ke <- cl/v
        d/dt(A1) = -ke * A1
        cp = A1/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "pheno", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

