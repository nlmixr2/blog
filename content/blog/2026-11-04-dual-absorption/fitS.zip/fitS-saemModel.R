saemModel <- list()

saemModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],ETA[3]);\ncmt(depot);\ncmt(slowdepot);\ncmt(central);\nrx_pred_=NA;\nrx_r_=NA;\ntka1=THETA[1]+ETA[1];\ntka2=THETA[2];\ntfr=THETA[3];\ntcl=THETA[4]+ETA[2];\ntv=THETA[5]+ETA[3];\nprop.sd=THETA[6];\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~exp(-tfr);\nrx_expr_3~1+rx_expr_0;\nf(depot)=1/(rx_expr_3);\nf(slowdepot)=1-(1/(rx_expr_3));\nrx_expr_1~exp(tka1);\nd/dt(depot)=-rx_expr_1*depot;\nrx_expr_2~exp(tka2);\nd/dt(slowdepot)=-rx_expr_2*slowdepot;\nd/dt(central)=rx_expr_1*depot+rx_expr_2*slowdepot-exp(tcl-tv)*central;\nrx_pred_=exp(-tv)*central;\nrx_expr__0~exp(-tv);\nrx_expr__1~rx_expr__0*central;\nrx_r_=Rx_pow_di((rx_expr__1*prop.sd),2);\nka1=exp(tka1);\nka2=exp(tka2);\nfr=1/(1+exp(-tfr));\ncl=exp(tcl);\nv=exp(tv);\ncp=rx_expr__1;\ntad=tad();\ndosenum=dosenum();\ntka1=THETA[1];\ntcl=THETA[4];\ntv=THETA[5];\neta.ka1=ETA[1];\neta.cl=ETA[2];\neta.v=ETA[3];\ncmt(cp);\ndvid(4);\n")

class(saemModel) <- "saemModelList"

