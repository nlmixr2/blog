ui <- function () 
{
    ini({
        tka1 <- 0.39934979621071
        label("Fast absorption rate ka1 (1/h)")
        tka2 <- -1.91435065846774
        label("Slow absorption rate ka2 (1/h)")
        tfr <- 0.480705217644309
        label("Fraction absorbed by the fast route")
        tcl <- 1.41825862513777
        label("Clearance CL (L/h)")
        tv <- 3.66471876329078
        label("Volume V (L)")
        prop.sd <- c(0, 0.0989535992305639)
        eta.ka1 ~ 0.0905430342384989
        eta.cl ~ 0.0816838473265449
        eta.v ~ 0.0258620437300465
    })
    model({
        ka1 <- exp(tka1 + eta.ka1)
        ka2 <- exp(tka2)
        fr <- expit(tfr, 0, 1)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        splitBolus(depot, depot, slowdepot)
        f(depot) <- fr
        f(slowdepot) <- 1 - fr
        d/dt(depot) <- -ka1 * depot
        d/dt(slowdepot) <- -ka2 * slowdepot
        d/dt(central) <- ka1 * depot + ka2 * slowdepot - cl/v * 
            central
        cp <- central/v
        cp ~ prop(prop.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "dual", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

