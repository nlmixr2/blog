ui <- function () 
{
    ini({
        tka1 <- 0.414233278752646
        label("Fast absorption rate ka1 (1/h)")
        tka2 <- -1.86615703260867
        label("Slow absorption rate ka2 (1/h)")
        tfr <- 0.447217288377486
        label("Fraction absorbed by the fast route")
        tcl <- 1.42088882139522
        label("Clearance CL (L/h)")
        tv <- 3.6720955375682
        label("Volume V (L)")
        prop.sd <- c(0, 0.0990175848193331)
        eta.ka1 ~ 0.0899715614980988
        eta.cl ~ 0.0811889584729327
        eta.v ~ 0.0258869720992983
    })
    model({
        ka1 <- exp(tka1 + eta.ka1)
        ka2 <- exp(tka2)
        fr <- expit(tfr, 0, 1)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        splitBolus(depot, depot, slowdepot)
        f(depot) <- fr
        f(slowdepot) <- 1 - fr
        d/dt(depot) <- -ka1 * depot
        d/dt(slowdepot) <- -ka2 * slowdepot
        d/dt(central) <- ka1 * depot + ka2 * slowdepot - cl/v * 
            central
        cp <- central/v
        cp ~ prop(prop.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "dual", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

