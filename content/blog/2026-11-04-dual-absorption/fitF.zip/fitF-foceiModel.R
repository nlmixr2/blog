foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],ETA[3]);\ncmt(depot);\ncmt(slowdepot);\ncmt(central);\nrx_expr_1~exp(-THETA[3]);\nrx_expr_5~1+rx_expr_1;\nf(depot)=1/(rx_expr_5);\nf(slowdepot)=1-(1/(rx_expr_5));\nrx_expr_2~ETA[1]+THETA[1];\nrx_expr_6~exp(rx_expr_2);\nd/dt(depot)=-rx_expr_6*depot;\nrx_expr_0~exp(THETA[2]);\nd/dt(slowdepot)=-rx_expr_0*slowdepot;\nrx_expr_3~ETA[2]+THETA[4];\nrx_expr_4~ETA[3]+THETA[5];\nrx_expr_9~rx_expr_6*depot;\nrx_expr_11~rx_expr_3-(rx_expr_4);\nrx_expr_12~exp(rx_expr_11);\nrx_expr_14~rx_expr_12*central;\nd/dt(central)=rx_expr_0*slowdepot+rx_expr_9-rx_expr_14;\nrx_expr_15~rx_expr_6*rx__sens_depot_BY_ETA_1___;\nd/dt(rx__sens_depot_BY_ETA_1___)=-rx_expr_6*depot-rx_expr_15;\nd/dt(rx__sens_slowdepot_BY_ETA_1___)=-rx_expr_0*rx__sens_slowdepot_BY_ETA_1___;\nd/dt(rx__sens_central_BY_ETA_1___)=rx_expr_0*rx__sens_slowdepot_BY_ETA_1___+rx_expr_9+rx_expr_15-rx_expr_12*rx__sens_central_BY_ETA_1___;\nd/dt(rx__sens_depot_BY_ETA_2___)=-rx_expr_6*rx__sens_depot_BY_ETA_2___;\nd/dt(rx__sens_slowdepot_BY_ETA_2___)=-rx_expr_0*rx__sens_slowdepot_BY_ETA_2___;\nd/dt(rx__sens_central_BY_ETA_2___)=rx_expr_0*rx__sens_slowdepot_BY_ETA_2___+rx_expr_6*rx__sens_depot_BY_ETA_2___-rx_expr_14-rx_expr_12*rx__sens_central_BY_ETA_2___;\nd/dt(rx__sens_depot_BY_ETA_3___)=-rx_expr_6*rx__sens_depot_BY_ETA_3___;\nd/dt(rx__sens_slowdepot_BY_ETA_3___)=-rx_expr_0*rx__sens_slowdepot_BY_ETA_3___;\nd/dt(rx__sens_central_BY_ETA_3___)=rx_expr_0*rx__sens_slowdepot_BY_ETA_3___+rx_expr_6*rx__sens_depot_BY_ETA_3___+rx_expr_14-rx_expr_12*rx__sens_central_BY_ETA_3___;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_7~exp(-(rx_expr_4));\nrx_expr_10~rx_expr_7*central;\nrx_pred_=rx_expr_10;\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_7*rx__sens_central_BY_ETA_1___;\nrx__sens_rx_pred__BY_ETA_2___=rx_expr_7*rx__sens_central_BY_ETA_2___;\nrx__sens_rx_pred__BY_ETA_3___=-rx_expr_7*central+rx_expr_7*rx__sens_central_BY_ETA_3___;\nrx_expr_13~rx_expr_10*THETA[6];\nrx_r_=Rx_pow_di((rx_expr_13),2);\nrx_expr_8~2*rx_expr_7;\nrx__sens_rx_r__BY_ETA_1___=rx_expr_8*(rx_expr_13)*rx__sens_central_BY_ETA_1___*THETA[6];\nrx__sens_rx_r__BY_ETA_2___=rx_expr_8*(rx_expr_13)*rx__sens_central_BY_ETA_2___*THETA[6];\nrx__sens_rx_r__BY_ETA_3___=-2*rx_expr_7*central*(rx_expr_13)*THETA[6]+rx_expr_8*(rx_expr_13)*rx__sens_central_BY_ETA_3___*THETA[6];\ncmt(cp);\ndvid(4);\n")

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- "rx_expr_1~exp(-THETA[3])\nrx_expr_5~1+rx_expr_1\nf(depot)=1/(rx_expr_5)\nf(slowdepot)=1-(1/(rx_expr_5))\nrx_expr_2~ETA[1]+THETA[1]\nrx_expr_6~exp(rx_expr_2)\nd/dt(depot)=-rx_expr_6*depot\nrx_expr_0~exp(THETA[2])\nd/dt(slowdepot)=-rx_expr_0*slowdepot\nrx_expr_3~ETA[2]+THETA[4]\nrx_expr_4~ETA[3]+THETA[5]\nrx_expr_9~rx_expr_6*depot\nrx_expr_11~rx_expr_3-(rx_expr_4)\nrx_expr_12~exp(rx_expr_11)\nrx_expr_14~rx_expr_12*central\nd/dt(central)=rx_expr_0*slowdepot+rx_expr_9-rx_expr_14\nrx_expr_15~rx_expr_6*rx__sens_depot_BY_ETA_1___\nd/dt(rx__sens_depot_BY_ETA_1___)=-rx_expr_6*depot-rx_expr_15\nd/dt(rx__sens_slowdepot_BY_ETA_1___)=-rx_expr_0*rx__sens_slowdepot_BY_ETA_1___\nd/dt(rx__sens_central_BY_ETA_1___)=rx_expr_0*rx__sens_slowdepot_BY_ETA_1___+rx_expr_9+rx_expr_15-rx_expr_12*rx__sens_central_BY_ETA_1___\nd/dt(rx__sens_depot_BY_ETA_2___)=-rx_expr_6*rx__sens_depot_BY_ETA_2___\nd/dt(rx__sens_slowdepot_BY_ETA_2___)=-rx_expr_0*rx__sens_slowdepot_BY_ETA_2___\nd/dt(rx__sens_central_BY_ETA_2___)=rx_expr_0*rx__sens_slowdepot_BY_ETA_2___+rx_expr_6*rx__sens_depot_BY_ETA_2___-rx_expr_14-rx_expr_12*rx__sens_central_BY_ETA_2___\nd/dt(rx__sens_depot_BY_ETA_3___)=-rx_expr_6*rx__sens_depot_BY_ETA_3___\nd/dt(rx__sens_slowdepot_BY_ETA_3___)=-rx_expr_0*rx__sens_slowdepot_BY_ETA_3___\nd/dt(rx__sens_central_BY_ETA_3___)=rx_expr_0*rx__sens_slowdepot_BY_ETA_3___+rx_expr_6*rx__sens_depot_BY_ETA_3___+rx_expr_14-rx_expr_12*rx__sens_central_BY_ETA_3___\nrx_yj_~2\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_expr_7~exp(-(rx_expr_4))\nrx_expr_10~rx_expr_7*central\nrx_pred_=rx_expr_10\nrx__sens_rx_pred__BY_ETA_1___=rx_expr_7*rx__sens_central_BY_ETA_1___\nrx__sens_rx_pred__BY_ETA_2___=rx_expr_7*rx__sens_central_BY_ETA_2___\nrx__sens_rx_pred__BY_ETA_3___=-rx_expr_7*central+rx_expr_7*rx__sens_central_BY_ETA_3___\nrx_expr_13~rx_expr_10*THETA[6]\nrx_r_=Rx_pow_di((rx_expr_13), 2)\nrx_expr_8~2*rx_expr_7\nrx__sens_rx_r__BY_ETA_1___=rx_expr_8*(rx_expr_13)*rx__sens_central_BY_ETA_1___*THETA[6]\nrx__sens_rx_r__BY_ETA_2___=rx_expr_8*(rx_expr_13)*rx__sens_central_BY_ETA_2___*THETA[6]\nrx__sens_rx_r__BY_ETA_3___=-2*rx_expr_7*central*(rx_expr_13)*THETA[6]+rx_expr_8*(rx_expr_13)*rx__sens_central_BY_ETA_3___*THETA[6]\nrx__ETA1=ETA[1]\nrx__ETA2=ETA[2]\nrx__ETA3=ETA[3]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],ETA[3]);\ncmt(depot);\ncmt(slowdepot);\ncmt(central);\nrx_expr_1~exp(-THETA[3]);\nrx_expr_5~1+rx_expr_1;\nrx_expr_6~1/(rx_expr_5);\nf(depot)=rx_expr_6;\nf(slowdepot)=1-(1/(rx_expr_5));\nrx_expr_2~ETA[1]+THETA[1];\nrx_expr_7~exp(rx_expr_2);\nd/dt(depot)=-rx_expr_7*depot;\nrx_expr_0~exp(THETA[2]);\nd/dt(slowdepot)=-rx_expr_0*slowdepot;\nrx_expr_3~ETA[2]+THETA[4];\nrx_expr_4~ETA[3]+THETA[5];\nd/dt(central)=rx_expr_0*slowdepot+rx_expr_7*depot-exp(rx_expr_3-(rx_expr_4))*central;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_8~exp(-(rx_expr_4));\nrx_expr_9~rx_expr_8*central;\nrx_pred_=rx_expr_9;\nrx_r_=Rx_pow_di((rx_expr_9*THETA[6]),2);\ntka1=THETA[1];\ntka2=THETA[2];\ntfr=THETA[3];\ntcl=THETA[4];\ntv=THETA[5];\nprop.sd=THETA[6];\neta.ka1=ETA[1];\neta.cl=ETA[2];\neta.v=ETA[3];\nka1=rx_expr_7;\nka2=rx_expr_0;\nfr=rx_expr_6;\ncl=exp(rx_expr_3);\nv=exp(rx_expr_4);\ncp=rx_expr_9;\ntad=tad();\ndosenum=dosenum();\ncmt(cp);\ndvid(4);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],ETA[1],ETA[2],ETA[3]);\ncmt(depot);\ncmt(slowdepot);\ncmt(central);\nrx_expr_1~exp(-THETA[3]);\nrx_expr_4~1+rx_expr_1;\nf(depot)=1/(rx_expr_4);\nf(slowdepot)=1-(1/(rx_expr_4));\nrx_expr_2~ETA[1]+THETA[1];\nrx_expr_5~exp(rx_expr_2);\nd/dt(depot)=-rx_expr_5*depot;\nrx_expr_0~exp(THETA[2]);\nd/dt(slowdepot)=-rx_expr_0*slowdepot;\nrx_expr_3~ETA[3]+THETA[5];\nd/dt(central)=rx_expr_0*slowdepot+rx_expr_5*depot-exp(ETA[2]+THETA[4]-(rx_expr_3))*central;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_6~exp(-(rx_expr_3));\nrx_expr_7~rx_expr_6*central;\nrx_pred_=rx_expr_7;\nrx_r_=Rx_pow_di((rx_expr_7*THETA[6]),2);\ncmt(cp);\ndvid(4);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- c(0L, 0L, 0L)

foceiModel[["eventEtaAll"]] <- c(0L, 0L, 0L)

class(foceiModel) <- "foceiModelList"

